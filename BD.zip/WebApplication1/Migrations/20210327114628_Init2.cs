﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication1.Migrations
{
    public partial class Init2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "PatientID",
                table: "Staff",
                type: "bigint",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Patient",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ages = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Telephone = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Dateofrequest = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DiseaseID = table.Column<long>(type: "bigint", nullable: true),
                    StaffID = table.Column<long>(type: "bigint", nullable: true),
                    Resultoftreatment = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Patient", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Disease",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NameIll = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Symptoms = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Duration = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Effects = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ID1 = table.Column<long>(type: "bigint", nullable: true),
                    ID2 = table.Column<long>(type: "bigint", nullable: true),
                    ID3 = table.Column<long>(type: "bigint", nullable: true),
                    PatientID = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Disease", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Disease_Patient_PatientID",
                        column: x => x.PatientID,
                        principalTable: "Patient",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Medicines",
                columns: table => new
                {
                    ID = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Indications = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Contraindications = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Packaging = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Cost = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DiseaseID = table.Column<long>(type: "bigint", nullable: true),
                    DiseaseID1 = table.Column<long>(type: "bigint", nullable: true),
                    DiseaseID2 = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Medicines", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Medicines_Disease_DiseaseID",
                        column: x => x.DiseaseID,
                        principalTable: "Disease",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Medicines_Disease_DiseaseID1",
                        column: x => x.DiseaseID1,
                        principalTable: "Disease",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Medicines_Disease_DiseaseID2",
                        column: x => x.DiseaseID2,
                        principalTable: "Disease",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Staff_PatientID",
                table: "Staff",
                column: "PatientID");

            migrationBuilder.CreateIndex(
                name: "IX_Disease_PatientID",
                table: "Disease",
                column: "PatientID");

            migrationBuilder.CreateIndex(
                name: "IX_Medicines_DiseaseID",
                table: "Medicines",
                column: "DiseaseID");

            migrationBuilder.CreateIndex(
                name: "IX_Medicines_DiseaseID1",
                table: "Medicines",
                column: "DiseaseID1");

            migrationBuilder.CreateIndex(
                name: "IX_Medicines_DiseaseID2",
                table: "Medicines",
                column: "DiseaseID2");

            migrationBuilder.AddForeignKey(
                name: "FK_Staff_Patient_PatientID",
                table: "Staff",
                column: "PatientID",
                principalTable: "Patient",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Staff_Patient_PatientID",
                table: "Staff");

            migrationBuilder.DropTable(
                name: "Medicines");

            migrationBuilder.DropTable(
                name: "Disease");

            migrationBuilder.DropTable(
                name: "Patient");

            migrationBuilder.DropIndex(
                name: "IX_Staff_PatientID",
                table: "Staff");

            migrationBuilder.DropColumn(
                name: "PatientID",
                table: "Staff");
        }
    }
}
