﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Drawing;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Medicines
    {
        [Display(Name = "Код лекарства")]
        public long ID { get; set; }

        [Display(Name = " Наименование")]
        public String Name { get; set; }

        [Display(Name = "Показания")]
        public String Indications { get; set; }

        [Display(Name = "Противопоказания")]
        public String Contraindications { get; set; }

        [Display(Name = "Упаковка")]
        public String Packaging { get; set; }

        [Display(Name = "Стоимость")]
        public String Cost { get; set; }
    }
}
