﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Drawing;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Position
    {
        [Display(Name = "Код должности")]
        public long ID { get; set; }

        [Display(Name = "Наименование должности")]
        public String Nameposition { get; set; }

        [Display(Name = "Оклад")]
        public String Salary { get; set; }

        [Display(Name = "Обязанности")]
        public String Responsibilities { get; set; }

        [Display(Name = "Требования")]
        public String Requirements { get; set; }
    }
}
