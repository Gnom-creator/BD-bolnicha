﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Drawing;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Staff
    {
        [Display(Name = "Код сотрудника")]
        public long ID { get; set; }

        [Display(Name = "ФИО")]
        public string name { get; set; }

        [Display(Name = "Возраст")]
        public string Ages { get; set; }

        [Display(Name = "Пол")]
        public string gender { get; set; }

        [Display(Name = " Адрес")]
        public string Address { get; set; }

        [Display(Name = "Телефон")]
        public string Telephone { get; set; }

        [Display(Name = "Паспортные данные")]
        public string Passportdata { get; set; }

        [Display(Name = " Код должности")]
        public long PositionID { get; set; }
    }
}
