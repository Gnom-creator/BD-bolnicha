﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Drawing;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Disease
    {
        [Display(Name = "Код болезни")]
        public long ID { get; set; }

        [Display(Name = " Наименование")]
        public String NameIll { get; set; }

        [Display(Name = "Симптомы")]
        public String Symptoms { get; set; }

        [Display(Name = "Продолжительность")]
        public String Duration { get; set; }

        [Display(Name = "Последствия")]
        public String Effects { get; set; }

        [Display(Name = "Код лекарства 1")]
        public long? ID1 { get; set; }

        [Display(Name = "Лекарства 1")]
        public DbSet<Medicines> MedicinesID1 { get; set; }

        [Display(Name = "Код лекарства 2")]
        public long? ID2 { get; set; }

        [Display(Name = "Лекарства 2")]
        public DbSet<Medicines> MedicinesID2 { get; set; }

        [Display(Name = "Код лекарства 3")]
        public long? ID3 { get; set; }

        [Display(Name = "Лекарства 3")]
        public DbSet<Medicines> MedicinesID3 { get; set; }
    }
}
