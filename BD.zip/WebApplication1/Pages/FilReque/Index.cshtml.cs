using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebApplication1.Pages.FilReque
{
    public class IndexModel : PageModel
    {
        private readonly WebApplication1.Data.WebApplication1Context _context;
        public IndexModel(WebApplication1.Data.WebApplication1Context context)
        {
            _context = context;
        }
        public IList<SelectListItem> SelPosition { get; set; }
        public void OnGet()
        {
            SelPosition = _context.Position.Select(p =>
                                    new SelectListItem
                                     {
                                         Value = p.ID.ToString(),
                                         Text = p.Nameposition
                                     }).ToList();
        }
    }
}
