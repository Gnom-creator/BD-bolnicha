﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Pages.Patients
{
    public class IndexModel : PageModel
    {
        private readonly WebApplication1.Data.WebApplication1Context _context;

        public IndexModel(WebApplication1.Data.WebApplication1Context context)
        {
            _context = context;
        }

        public IList<Patient> Patient { get;set; }
        public IList<Staff> Staff { get; set; }
        public IList<Disease> Disease { get; set; }

        public async Task OnGetAsync()
        {
            Patient = await _context.Patient.ToListAsync();
            Disease = await _context.Disease.ToListAsync();
            Staff = await _context.Staff.ToListAsync();
        }
    }
}
