﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Drawing;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Patient
    {
        [Display(Name = "ФИО пациента")]
        public long ID { get; set; }

        [Display(Name = "Возраст")]
        public string Ages { get; set; }

        [Display(Name = "Пол")]
        public string gender { get; set; }

        [Display(Name = " Адрес")]
        public string Address { get; set; }

        [Display(Name = "Телефон")]
        public string Telephone { get; set; }

        [Display(Name = "Дата обращения")]
        public DateTime Dateofrequest { get; set; }

        [Display(Name = "Код болезни")]
        public long? DiseaseID { get; set; }

        [Display(Name = "Болезни")]
        public DbSet<Disease> Disease { get; set; }

        [Display(Name = "Код сотрудника")]
        public long? StaffID { get; set; }

        [Display(Name = "Сотрудник")]
        public DbSet<Staff> Staff { get; set; }

        [Display(Name = " Результат лечения")]
        public String Resultoftreatment { get; set; }
    }
}
