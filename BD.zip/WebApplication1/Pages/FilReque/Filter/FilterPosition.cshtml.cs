using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Pages.FilReque.Filter
{
    public class FilterPositionModel : PageModel
    {
        private readonly WebApplication1.Data.WebApplication1Context _context;

        public FilterPositionModel(WebApplication1.Data.WebApplication1Context context)
        {
            _context = context;
        }
        public Position Position { get; set; }
        public IList<Staff> Staff { get; set; }
      

        public async Task<IActionResult> OnGetAsync(long? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            Position = _context.Position.First(m => m.ID == id);
            if(Position == null)
            {
                return NotFound();
            }
            Staff = await _context.Staff.Where(m => m.PositionID == Position.ID).ToListAsync();
            return Page();
        }
    }
}
