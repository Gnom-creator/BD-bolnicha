from flask import Flask, request, jsonify, send_from_directory, render_template, send_file
import cv2
import numpy as np
from ultralytics import YOLO
import sqlite3
from datetime import datetime
import json
import io
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import openpyxl
from openpyxl.styles import Font
import os
from fpdf import FPDF


app = Flask(__name__)

# Грузим модель один раз
model = YOLO('yolov8n.pt')

# Инициализация SQLite базы данных
def init_db():
    conn = sqlite3.connect('detections.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS detections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            image_path TEXT,
            count INTEGER,
            details TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()  # Инициализируем БД при запуске

def bbox_iou(boxA, boxB):
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])
    interArea = max(0, xB - xA) * max(0, yB - yA)
    if interArea == 0:
        return 0.0
    boxAArea = (boxA[2] - boxA[0]) * (boxA[3] - boxA[1])
    boxBArea = (boxB[2] - boxB[0]) * (boxB[3] - boxB[1])
    iou = interArea / float(boxAArea + boxBArea - interArea)
    return iou

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process_image():
    file = request.files['image']
    img = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_COLOR)

    results = model(img)
    output_img = img.copy()
    
    class_names = results[0].names

    # Находим id классов 'person' и 'backpack'
    person_id = None
    backpack_id = None
    for i, name in class_names.items():
        if name == 'person':
            person_id = i
        elif name == 'backpack':
            backpack_id = i

    people_boxes = []
    backpack_boxes = []

    # Собираем боксы для людей и рюкзаков
    for box in results[0].boxes:
        cls_id = int(box.cls[0])
        xyxy = list(map(int, box.xyxy[0]))
        if cls_id == person_id:
            people_boxes.append(xyxy)
        elif cls_id == backpack_id:
            backpack_boxes.append((xyxy, float(box.conf[0])))

    count = 0
    details = []  # Список для деталей о найденных рюкзаках
    # Для каждого рюкзака проверим, пересекается ли он с кем-то из людей
    for bbox, conf in backpack_boxes:
        overlap = False
        for person_bbox in people_boxes:
            if bbox_iou(bbox, person_bbox) > 0.15:  # Порог IoU. Можно регулировать.
                overlap = True
                break
        if not overlap:
            count += 1
            x1, y1, x2, y2 = bbox
            cv2.rectangle(output_img, (x1, y1), (x2, y2), (0,255,0), 2)
            cv2.putText(output_img, f'backpack {conf:.2f}', (x1, y1-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
            # Сохраняем детали
            details.append({
                'bbox': [x1, y1, x2, y2],
                'confidence': conf
            })

    # Сохраняем обработанное изображение (с уникальным именем, чтобы избежать перезаписи)
    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    image_path = f'static/result_{timestamp_str}.jpg'
    cv2.imwrite(image_path, output_img)

    # Сохраняем в БД
    timestamp = datetime.now().isoformat()
    conn = sqlite3.connect('detections.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO detections (timestamp, image_path, count, details)
        VALUES (?, ?, ?, ?)
    ''', (timestamp, image_path, count, json.dumps(details)))
    conn.commit()
    conn.close()

    return jsonify(count=count, image_path=image_path)

# Эндпоинт для генерации PDF отчёта
@app.route('/report/pdf')
def generate_pdf_report():
    conn = sqlite3.connect('detections.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, timestamp, image_path, count, details FROM detections ORDER BY timestamp DESC")
    rows = cursor.fetchall()
    conn.close()

    pdf = FPDF()
    pdf.add_page()
    pdf.add_font('DejaVu', '', 'DejaVuSans.ttf', uni=True)  # Для поддержки русского (скачайте шрифт DejaVuSans.ttf и положите в проект)
    pdf.set_font('DejaVu', '', 12)

    # Заголовок
    pdf.cell(200, 10, txt="Отчёт по найденным забытым рюкзакам в аэропорту", ln=True, align='C')

    # Ширины колонок (сумма ~190 для A4, с запасом на поля)
    col_widths = [10, 40, 50, 20, 70]  # ID, Время, Ссылка, Количество, Детали

    # Заголовки таблицы
    headers = ["ID", "Время", "Ссылка", "Кол-во", "Детали"]
    for i, header in enumerate(headers):
        pdf.cell(col_widths[i], 10, header, border=1, align='C')
    pdf.ln()

    # Данные таблицы с multi_cell для переноса
    for row in rows:
        # ID
        pdf.cell(col_widths[0], 10, str(row[0]), border=1, align='C')
        # Время
        pdf.multi_cell(col_widths[1], 10, row[1], border=1, align='L')
        pdf.set_xy(pdf.get_x() + col_widths[0] + col_widths[1], pdf.get_y() - 10)  # Корректировка позиции после multi_cell
        # Ссылка (перенос если длинная)
        pdf.multi_cell(col_widths[2], 10, row[2], border=1, align='L')
        pdf.set_xy(pdf.get_x() + col_widths[0] + col_widths[1] + col_widths[2], pdf.get_y() - 10)
        # Количество
        pdf.cell(col_widths[3], 10, str(row[3]), border=1, align='C')
        # Детали (перенос для длинных bounding boxes)
        pdf.multi_cell(col_widths[4], 10, row[4], border=1, align='L')
        pdf.ln()  # Новая строка после всей строки

    # Вывод в память и отправка
    pdf_output = io.BytesIO()
    pdf_output.write(pdf.output(dest='S').encode('latin1'))  # Или используйте pdf.output(dest='S') для строки
    pdf_output.seek(0)
    return send_file(pdf_output, download_name='report.pdf', as_attachment=True, mimetype='application/pdf')

# Эндпоинт для генерации Excel отчёта
@app.route('/report/excel')
def generate_excel_report():
    conn = sqlite3.connect('detections.db')
    c = conn.cursor()
    c.execute('SELECT * FROM detections ORDER BY timestamp DESC')
    rows = c.fetchall()
    conn.close()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Отчёт по рюкзакам"

    # Заголовки
    headers = ['ID', 'Время', 'Путь к изображению', 'Количество', 'Детали']
    for col_num, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_num)
        cell.value = header
        cell.font = Font(bold=True)

    # Данные
    for row_num, row in enumerate(rows, 2):
        ws.cell(row=row_num, column=1).value = row[0]

        # Исправление: Форматируем время во втором столбце (из ISO в читаемый формат)
        try:
            formatted_time = datetime.fromisoformat(row[1]).strftime('%Y-%m-%d %H:%M:%S')
        except ValueError:
            formatted_time = row[1]  # Если формат неверный, оставляем как есть
        ws.cell(row=row_num, column=2).value = formatted_time

        ws.cell(row=row_num, column=3).value = row[2]
        ws.cell(row=row_num, column=4).value = row[3]

        # Форматируем детали аналогично PDF для лучшей читаемости
        try:
            details_list = json.loads(row[4])
            formatted_details = '\n'.join([f'Рюкзак {i}: Bbox {det.get("bbox", "N/A")}, Уверенность: {det.get("confidence", 0):.2f}' for i, det in enumerate(details_list, 1)])
        except (json.JSONDecodeError, TypeError):
            formatted_details = 'Нет деталей или ошибка в данных'
        ws.cell(row=row_num, column=5).value = formatted_details

    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    return send_file(buffer, as_attachment=True, download_name='report.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

@app.route('/static/<path:path>')
def send_static(path):
    return send_from_directory('static', path)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)